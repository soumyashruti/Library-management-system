import firebase from 'firebase/app'
import 'firebase/database'

var firebaseConfig = {
    apiKey: "AIzaSyD__gC5Xy6IDCGTEw7C8u0U8ZFozK2NcwA",
    authDomain: "contact-curd-react.firebaseapp.com",
    databaseURL: "https://contact-curd-react.firebaseio.com",
    projectId: "contact-curd-react",
    storageBucket: "contact-curd-react.appspot.com",
    messagingSenderId: "287720185653",
    appId: "1:287720185653:web:3bcb37f7dd143df1f2b67c"
  };
  // Initialize Firebase
  var fireDb = firebase.initializeApp(firebaseConfig);


export default fireDb.database().ref();