import React, { Component } from 'react'
import AdminNavbar from '../../../navigationbar/Adminnav';
//import {Link} from 'react-router-dom';
import axiosInstance  from '../../../Inter/Interceptor';

const form = {
  border:"lightgrey solid 2px",
  boxShadow: "0px 10px 30px black",
  borderRadius: "10px",
  marginLeft:"150px",
  backgroundColor:"white"
}

export default class AddUser extends Component{
  
    constructor(props) {
      super(props)
  
      this.onChangeName = this.onChangeName.bind(this);
      this.onChangeEmail = this.onChangeEmail.bind(this);
      this.onChangePassword = this.onChangePassword.bind(this);
  
      this.onSubmit = this.onSubmit.bind(this);
      this.state = {
        name: '',
        email: '',
        password:'',
        
      }
  }
  
  onChangeName(e) {
    this.setState({ name: e.target.value })
  }
  
  onChangeEmail(e) {
    this.setState({ email: e.target.value })
  }
  
  onChangePassword(e) {
    this.setState({ password: e.target.value})
  }
  
  
  onSubmit(e) {
    e.preventDefault()
  
    const userObject = {
      name: this.state.name,
      email: this.state.email,
      password:this.state.password
    };
    // console.log(userObject);
    axiosInstance().post('users/addUser', userObject)
    .then((res) => {
        console.log(res.data)
        // alert(res.data.message);
        alert('User added Successfully');
    }).catch((error) => {
        console.log(error)
    });
  
  this.setState({ name: '',email: '',password:''})
  }
  render() {
    return (
      <>
      <div>
        <AdminNavbar/>
      </div>
        <div>
            <div className="row">
                    <div className="col-10">
                        <div className="row">
                            <div className="col-2"></div>
                            <div className="col-8">
                            <div className="jumbotron mt-5" style={form}>
        <div>
            <h3 style={{textAlign:"center", marginBottom:"30px", color:"crimson"}}>Add your user details here....</h3>

        <form onSubmit={this.onSubmit} style={{width:"500px"}}>
          <div style={{marginLeft:"25px"}}>
          <div className="form-row">
            <div className="col">
              <label htmlFor="name">Name<span className="required text-danger">*</span></label>
              <input type="text" required name="name" id="name" value={this.state.name} onChange={this.onChangeName}   className="form-control"  placeholder="name"/>
            </div>
          </div>

          <div className="form-row">
            <div className="col">
              <label htmlFor="email">Email <span className="required text-danger">*</span></label>
              <input type="text" name="email" id="email" value={this.state.email} onChange={this.onChangeEmail} maxLength="30"   className="form-control" placeholder="email" />
            </div>
          </div>

          <div className="form-row">
            <div className="col">
              <label htmlFor="password">Password <span className="required text-danger ">*</span></label>
              <input type="password" className="form-control" name="password"  value={this.state.password} onChange={this.onChangePassword}   placeholder="password" id="password" />
            </div>
          </div>
                     
          </div>
            <div className=" text-left " style={{marginLeft:"20px", marginTop:"5px"}}>
                  <button type="submit" className="btn btn-info m-2 p-2" style={{width:"100px" }}>AddUser</button>
                  {/* <button type="reset" className="btn btn-outline-info m-2 p-2"> Reset</button> */}
            </div>
       </form>
      </div>
     </div>
    </div>
  <div className="col-2"></div>
  </div>
  </div>
  </div>        
  </div>
  </>
  )
  }
  }





















// import React from 'react'

// import {Link} from 'react-router-dom'
// import AdminNavbar from '../../../navigationbar/Adminnav'


// export default function AddUser() 
// {
//     return (
//         <>
//             <div>
//                 <AdminNavbar/>
//             </div>
//             <h1>Add User Which You Want to Add</h1>
//         </>
// )
// }





















            {/* <div id="id01" class="modal">
                <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">&times;</span>
                <form class="modal-content" action="/action_page.php"/>
                <div class="container">
                    <h1>Sign Up</h1>
                    <p>Please fill in this form to create an account.</p>
                    
                    <label for="email"><b>Email</b></label>
                    <input type="text" placeholder="Enter Email" name="email" required />

                    <label for="psw"><b>Password</b></label>
                    <input type="password" placeholder="Enter Password" name="psw" required /> 
                        

                    <label for="con-pwd"><b>Confirm Password</b></label>
                    <input type="password" placeholder="Repeat Password" name="con-pwd" required />
                    
                    <label>
                        <input type="checkbox" checked="checked" name="remember" style="margin-bottom:15px"> Remember me<input/>
                    <label/>

                    <p>By creating an account you agree to our <a href="#" style="color:dodgerblue">Terms & Privacy</a>.</p>

                    <div class="clearfix">
                        <button type="button" onclick="document.getElementById('id01').style.display='none'" class="cancelbtn">Cancel</button>
                        <button type="submit" class="signupbtn">Sign Up</button>
                    </div>
                </input>
                <form/>
            </label>
        </div>
        
    )
</div> */}

