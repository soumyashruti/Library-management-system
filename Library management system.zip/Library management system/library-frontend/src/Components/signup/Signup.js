import React, { Component } from 'react'
//import { Link } from 'react-router-dom';
import HomeNavbar from '../../navigationbar/Homenav';
//import { FormErrors } from '../Welcome/FormErrors';
import Axios from 'axios';
//import './Signup.css';

const form = {
  border:"lightgrey solid 2px",
  boxShadow: "0px 10px 30px black",
  borderRadius: "10px",
  marginLeft:"150px",
  backgroundColor:"white"
}

export default class SignUp extends Component{

constructor (props) {
  super(props);

  this.onChangeName = this.onChangeName.bind(this);
  this.onChangeEmail = this.onChangeEmail.bind(this);
  this.onChangePassword = this.onChangePassword.bind(this);

  this.onSubmit = this.onSubmit.bind(this);

  this.state = {
    name: '',
    email: '',
    password: '',
  }
}

onChangeName(e) {
  this.setState({ name: e.target.value })
}

onChangeEmail(e) {
  this.setState({ email: e.target.value })
}

onChangePassword(e) {
  this.setState({ password: e.target.value})
}

onSubmit(e) {
  e.preventDefault()

  const userObject = {
    name: this.state.name,
    email: this.state.email,
    password:this.state.password
  };
  // console.log(userObject);
  Axios.post('http://localhost:8080/users/register', userObject)
  .then((res) => {
      console.log(res.data)
      // alert(res.data.message);
      alert(' User register Successfully');
  }).catch((error) => {
      console.log(error)
  });

this.setState({ name: '',email: '',password:''})
}

 render() {
  return ( 
        <>
          <div>
            <HomeNavbar/>
          </div>
        
            <div>
                <div className="row">
                        <div className="col-10">
                            <div className="row">
                                <div className="col-2"></div>
                                <div className="col-8">
                                <div className="jumbotron mt-5" style={form}>
          <div>
            <h3 style={{textAlign:"center", marginBottom:"30px", color:"crimson"}}>Enter user details</h3>

            <form onSubmit={this.onSubmit} style={{width:"500px"}}>
            <div style={{marginLeft:"25px"}}>
              <div className="form-row">
                <div className="col" style={{marginBottom:"15px"}}>
                  {/* <label htmlFor="name">Name<span className="required text-danger">*</span></label> */}
                  <input type="text" required name="name" id="name" value={this.state.name} onChange={this.onChangeName}   className="form-control"  placeholder="enter name" />
                </div>
                </div>

                <div className="form-row">
                <div className="col" style={{marginBottom:"15px"}}>
                  {/* <label htmlFor="email">Email <span className="required text-danger">*</span></label> */}
                  <input type="text" name="email" id="email" value={this.state.email} onChange={this.onChangeEmail} maxLength="30"   className="form-control" placeholder="enter email" />
                </div>
                </div>

                <div className="form-row" style={{marginBottom:"15px"}}>
                <div className="col">
                  {/* <label htmlFor="password">Password <span className="required text-danger ">*</span></label> */}
                  <input type="password" className="form-control" name="password" value={this.state.password} onChange={this.onChangePassword}   placeholder="enter password" id="password" />
                </div>
                </div>
                  <div className=" text-left " style={{marginTop:"15px"}}>
                      <button type="submit" className="btn btn-info m-2 p-2" style={{width:"150px" }}> SignUp</button>
                  </div>
              </div>
          </form>
          </div>
        </div>
      </div>
    <div className="col-2"></div>
  </div>
  </div>
  </div>        
  </div>
  </>
    
)
}
}


// import React, { Component } from 'react'
// import HomeNavbar from '../../Navbar/HomeNavbar';
// import {Link} from 'react-router-dom';
// import { FormErrors } from '../Welcome/FormErrors';
// import axiosInstance  from '../../Inter/Interceptor';
// import jwtDecode from "jwt-decode";
// import Axios from 'axios'


// const form = {
//   border:"darkseagreen solid 2px",
//   padding: "40px",
//   marginTop: "30px",
//   marginLeft: "380px",
//   marginRight: "485px",
//   color: "firebrick",
//   fontWeight: "600"
// }

// const btn ={
//   marginTop: "15px",
//   // marginLeft: "5px" ,
//   paddingLeft: "40px",
//   paddingRight: "110px",
//   marginBottom: "5px",
//   fontSize: "23px",
//    //marginRight:"5px"
 
// }

// const welcome ={
  
//   marginLeft: "1px",
//   marginBottom: "10px",
//   color: "black",
//   textShadow:" 2px 2px red",
//   fontSize: "40px"
// }

// const greet ={
//   marginTop:"1px",
//   marginBottom:"1px",

// }

// // const glad={
// //   paddingTop:"5px",
// //   paddingBottom:"5px"
// // }


// export default class Register extends Component{
  
//   constructor(props) {
//     super(props)

//     this.onChangeName = this.onChangeName.bind(this);
//     this.onChangeEmail = this.onChangeEmail.bind(this);
//     this.onChangePassword = this.onChangePassword.bind(this);

//     this.onSubmit = this.onSubmit.bind(this);
//     this.state = {
//       name: '',
//       email: '',
//       password:'',
      
//     }
// }

// onChangeName(e) {
//   this.setState({ name: e.target.value })
// }

// onChangeEmail(e) {
//   this.setState({ email: e.target.value })
// }

// onChangePassword(e) {
//   this.setState({ password: e.target.value})
// }


// onSubmit(e) {
//   e.preventDefault()

//   const userObject = {
//     name: this.state.name,
//     email: this.state.email,
//     password:this.state.password
//   };
//   // console.log(userObject);
//   Axios.post('http://localhost:4040/users/register', userObject)
//   .then((res) => {
//       console.log(res.data)
//       // alert(res.data.message);
//       alert('Register Successfully');
//   }).catch((error) => {
//       console.log(error)
//   });

// this.setState({ name: '',email: '',password:''})
// }
// render() {
//   return (
//     <>
//     <div>
//       <HomeNavbar/>
//     </div>
   
//       <div>
//           <div className="row p-2">
             
//                   <div className="col-10">
//                       <div className="row">
//                           <div className="col-2"></div>
//                           <div className="col-8">

//                           <div className="jumbotron mt-5">
//     <div>
//       <h3>Register</h3>

      

//       <form onSubmit={this.onSubmit}>
//         <div className="form-row">
//           <div className="col">
//             <label htmlFor="name">Name<span className="required text-danger">*</span></label>
//             <input type="text" required name="name" id="name" value={this.state.name} onChange={this.onChangeName}   className="form-control" />
//           </div>

//           <div className="col">
//             <label htmlFor="email">Email <span className="required text-danger">*</span></label>
//             <input type="text" name="email" id="email" 
//             value={this.state.email} onChange={this.onChangeEmail} 
//             maxLength="30"   className="form-control" placeholder="ex: abc@gmail.com" />
//           </div>
      
//           <div className="col">
//             <label htmlFor="password">Phone Number <span className="required text-danger ">*</span></label>
//             <input type="password" className="form-control" name="password"
//             value={this.state.password} onChange={this.onChangePassword}   placeholder="Password"
//               id="password" />
//           </div>
//           {/* <div className="col">
//             <label htmlFor="password"> <span className="required text-danger ">*</span></label>
//             <input type="text" className="form-control" name="password"
//             value={this.state.password} onChange={this.onChangePassword}   placeholder="Password"
//               id="password" />
//           </div> */}
        
//            </div>
//            <div className=" text-left ">
             
//                           <button type="submit" className="btn btn-outline-success m-2 p-2"> Submit</button>
//                           {/* <button type="reset" className="btn btn-outline-info m-2 p-2"> Reset</button> */}
//                      </div>
//      </form>
//     </div>
//    </div>
//                           </div>
//                           <div className="col-2"></div>
//                       </div>
//                   </div>
//           </div>        
//       </div>
//       </>
//   )
// }
// }