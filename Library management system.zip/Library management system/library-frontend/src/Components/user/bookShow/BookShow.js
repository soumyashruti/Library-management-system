import React, { Component } from 'react'
import { Link } from 'react-router-dom';
import UserNavbar from '../../../navigationbar/Usernav';
import axiosInstance from '../../../Inter/Interceptor';

export default class BookShow extends Component {

    constructor(props) {
        super(props);
        this.state = { booksCollection: [] } 
        this.deleteBook = this.deleteBook.bind(this);
    }

    deleteBook = (bookid) => {
        if (window.confirm('Sure, you want to delete the record?')) {
            axiosInstance().delete('/books/'+ bookid)
        .then((res) => {
            console.log('Book deleted successfully!!')
            alert('Deleted succesfully')
            this.setState({
                booksCollection: this.state.booksCollection.filter( remove => remove.bookid !== bookid)
            })
        }).catch((error) => {
            console.log(error)
        })
    }}
    componentDidMount() {
        //console.log("Component Mounted");
        axiosInstance().get('/books/allBooks')
            .then(res => {
               // console.log("res",res.data);
                this.setState({ booksCollection: res.data.book_info });
            })
            .catch(function (error) {
                console.log(error);
            })
    }
    
    render() {
    return (
        <>
        <div ><UserNavbar/></div>
        <div>
             <div className="row ">
                    <div className="col-10">
                        <div className="row">
                             <div className="col-2"></div> 
                            <div className="col-10">
                            <h2 className="text-center text-black">Books List</h2>
                            
                            <table class="table table-hover table-striped table-bordered table-secondary table-condensed mt-2">
                                    <thead class="thead-info table-hover" style={{backgroundColor:"IndianRed", textAlign:"center"}}>
                                    <tr>                                                                                                        
                                        <th scope="col">Book id</th>
                                        <th scope="col">Book title</th>
                                        <th scope="col">Category</th>
                                        <th scope="col">Author</th>
                                        <th scope="col">Copies</th>
                                        <th scope="col">Book pub</th>
                                        <th scope="col">Publisher name</th>
                                        <th scope="col">Isbn</th>
                                        <th scope="col">Copyright year</th>
                                        <th scope="col">Date added</th>
                                        <th scope="col">status</th>
                                        {/* <th scope="col">Action</th> */}
						            </tr>
                                    </thead>
                                    <tbody style={{backgroundColor:"white", textAlign:"center"}}>
                                   
                                        {this.state.booksCollection.map(book => (
                                            <tr>
                                                <td>
                                                    {book.bookid}  
                                                </td>
                                                 <td>
                                                    {book.booktitle}
                                                </td> 
                                                <td>
                                                    {book.categoryid}
                                                </td>
                                                <td>
                                                    {book.author}
                                                </td>
                                                <td>
                                                    {book.bookcopies}
                                                </td>
                                                <td>
                                                    {book.bookpub}
                                                </td>
                                                <td>
                                                    {book.publishername}
                                                </td>
                                                <td>
                                                    {book.isbn}
                                                </td>
                                                <td>
                                                    {book.copyrightyear}
                                                </td>
                                                <td>
                                                    {book.dateadded}
                                                </td>
                                                <td>
                                                    {book.status}
                                                </td>
                                                {/* <td >
                                                <Link to={{pathname:"/editBooks",query:book.bookid}} state={book.bookid}><button size="sm" style={{ cursor:"pointer", width:"100px", margin:"5px 0"}} className="btn text-danger fa fa-pencil"></button></Link>
                                                <button size="sm" onClick={() => this.deleteBook(book.bookid)} style={{ cursor:"pointer", width:"100px"}}className="btn text-danger fa fa-trash"></button>
                                                </td> */}
                                            </tr>
                                        ))}

                                    </tbody>
                            </table>

                            </div>
                            {/* <div className="col-2"></div> */}
                        </div>
                    </div>
              </div>          
        </div>
        </>
    )
}
}































// //import Axios from 'axios';
// import React, { Component } from 'react'
// //import { Link } from 'react-router-dom';
// import UserNavbar from '../../../navigationbar/Usernav';
// import axiosInstance from '../../../Inter/Interceptor';

// export default class ShowBooks extends Component {

//     constructor(props) {
//         super(props);
//         this.state = { booksCollection: [] } 
//         this.deleteBook = this.deleteBook.bind(this);
//     }

//     deleteBook = (bookid) => {
//         if (window.confirm('Sure, you want to delete the record?')) {
//             axiosInstance().delete('/book/'+ bookid)
//         .then((res) => {
//             console.log('Book deleted successfully!!')
//             alert('Deleted succesfully')
//             this.setState({
//                 booksCollection: this.state.booksCollection.filter( remove => remove.bookid !== bookid)
//             })
//         }).catch((error) => {
//             console.log(error)
//         })
//     }}
//     componentDidMount() {
//         console.log("Component Mounted");
//         axiosInstance().get('/book/allBooks')
//             .then(res => {
//                // console.log("res",res.data);
//                 this.setState({ booksCollection: res.data.book_info });
//             })
//             .catch(function (error) {
//                 console.log(error);
//             })
//     }
    
//     render() {
//     return (
//         <>
//         <div ><UserNavbar/></div>
//         <div>
//              <div className="row p-2">
                    
//                     <div className="col-10">
//                         <div className="row">
//                              <div className="col-2"></div> 
//                             <div className="col-8">
//                             <h2 className="text-center text-white">Books List</h2>
                            
//                             <table class="table table-hover table-bordered table-secondary table-condensed mt-3">
//                                     <thead class="thead-info table-hover">
//                                     <tr>                                                                                                        
//                                         <th scope="col">Book id</th>
//                                         <th scope="col">Book title</th>
//                                         <th scope="col">Category</th>
//                                         <th scope="col">Author</th>
//                                         <th scope="col">Copies</th>
//                                         <th scope="col">Book pub</th>
//                                         <th scope="col">Publisher name</th>
//                                         <th scope="col">Isbn</th>
//                                         <th scope="col">Copyright year</th>
//                                         <th scope="col">Date added</th>
//                                         <th scope="col">status</th>
//                                         <th scope="col">Action</th>
// 						            </tr>
//                                     </thead>
//                                     <tbody>
                                   
//                                         {this.state.booksCollection.map(book => (
//                                             <tr>
//                                                 <td>
//                                                     {book.bookid}  
//                                                 </td>
//                                                  <td>
//                                                     {book.booktitle}
//                                                 </td> 
//                                                 <td>
//                                                     {book.categoryid}
//                                                 </td>
//                                                 <td>
//                                                     {book.author}
//                                                 </td>
//                                                 <td>
//                                                     {book.bookcopies}
//                                                 </td>
//                                                 <td>
//                                                     {book.bookpub}
//                                                 </td>
//                                                 <td>
//                                                     {book.publishername}
//                                                 </td>
//                                                 <td>
//                                                     {book.isbn}
//                                                 </td>
//                                                 <td>
//                                                     {book.copyrightyear}
//                                                 </td>
//                                                 <td>
//                                                     {book.dateadded}
//                                                 </td>
//                                                 <td>
//                                                     {book.status}
//                                                 </td>
                                                
//                                             </tr>
//                                         ))}

//                                     </tbody>
//                             </table>

//                             </div>
//                             <div className="col-2"></div>
//                         </div>
//                     </div>
//               </div>          
//         </div>
//         </>
//     )
// }
// }



















// // // import React from 'react';
// // // import ShowBooks from '../../Admin/ShowBooks/ShowBooks';


// // // function BookShow(){
// // //     return(
// // //         <ShowBooks/>
// // //     )
// // // }

// // // export default BookShow;
// // //import Axios from 'axios';
// // import React, { Component } from 'react'
// // //import { Link } from 'react-router-dom';
// // import UserNavbar from '../../../navigationbar/Usernav';
// // import axiosInstance from '../../../Inter/Interceptor';

// // export default class ShowBooks extends Component {

// //     constructor(props) {
// //         super(props);
// //         this.state = { booksCollection: [] } 
// //         this.deleteBook = this.deleteBook.bind(this);
// //     }

// //     deleteBook = (bookid) => {
// //         if (window.confirm('Sure you want to delete the record?')) {
// //             axiosInstance().delete('/book/'+ bookid)
// //         .then((res) => {
// //             console.log('Book deleted successfully!!')
// //             alert('Deleted succesfully')
// //             this.setState({
// //                 booksCollection: this.state.booksCollection.filter( remove => remove.bookid !== bookid)
// //             })
// //         }).catch((error) => {
// //             console.log(error)
// //         })
// //     }}
// //     componentDidMount() {
// //         console.log("Component Mounted");
// //         axiosInstance().get('/books/allBooks')
// //             .then(res => {
// //                // console.log("res",res.data);
// //                 this.setState({ booksCollection: res.data.book_info });
// //             })
// //             .catch(function (error) {
// //                 console.log(error);
// //             })
// //     }
    
// //     render() {
// //     return (
// //         <>
// //         <div ><UserNavbar/></div>
// //         <div>
// //              <div className="row p-2">
                    
// //                     <div className="col-10">
// //                         <div className="row">
// //                              <div className="col-2"></div> 
// //                             <div className="col-10">
// //                             <h2 className="text-center text-dark">Books List</h2>
                            
// //                             <table class="table table-hover table-bordered table-secondary table-condensed mt-3">
// //                                     <thead class="thead-info table-hover">
// //                                     <tr>
// //                                     <th scope="col">Book id</th>
// //                                         <th scope="col">Book title</th>
// //                                         <th scope="col">Category</th>
// //                                         <th scope="col">Author</th>
// //                                         <th scope="col">Copies</th>
// //                                         <th scope="col">Book pub</th>
// //                                         <th scope="col">Publisher name</th>
// //                                         <th scope="col">Isbn</th>
// //                                         <th scope="col">Copyright year</th>
// //                                         <th scope="col">Date added</th>
// //                                         <th scope="col">status</th>
// //                                         {/* <th scope="col">ACTION</th> */}
// // 						            </tr>
// //                                     </thead>
// //                                     <tbody>
                                   
// //                                         {this.state.booksCollection.map(book => (
// //                                             <tr>
// //                                                 <td>
// //                                                     {book.bookid}  
// //                                                 </td>
// //                                                  <td>
// //                                                     {book.booktitle}
// //                                                 </td> 
// //                                                 <td>
// //                                                     {book.categoryid}
// //                                                 </td>
// //                                                 <td>
// //                                                     {book.author}
// //                                                 </td>
// //                                                 <td>
// //                                                     {book.bookcopies}
// //                                                 </td>
// //                                                 <td>
// //                                                     {book.bookpub}
// //                                                 </td>
// //                                                 <td>
// //                                                     {book.publishername}
// //                                                 </td>
// //                                                 <td>
// //                                                     {book.isbn}
// //                                                 </td>
// //                                                 <td>
// //                                                     {book.copyrightyear}
// //                                                 </td>
// //                                                 <td>
// //                                                     {book.dateadded}
// //                                                 </td>
// //                                                 <td>
// //                                                     {book.status}
// //                                                 </td>
// //                                                 {/* <td >
// //                                                 <Link to={{pathname:"/EditBooks",query:book.book_id}} state={book.book_id}><button size="sm" style={{ cursor:"pointer", width:"100px", margin:"5px 0"}} className="btn text-danger fa fa-pencil"></button></Link>
// //                                                 <button size="sm" onClick={() => this.deleteBook(book.book_id)} style={{ cursor:"pointer", width:"100px"}}className="btn text-danger fa fa-trash"></button>
// //                                                 </td> */}
// //                                             </tr>
// //                                         ))}

// //                                     </tbody>
// //                             </table>

// //                             </div>
// //                             <div className="col-2"></div>
// //                         </div>
// //                     </div>
// //               </div>          
// //         </div>
// //         </>
// //     )
// // }
// // }