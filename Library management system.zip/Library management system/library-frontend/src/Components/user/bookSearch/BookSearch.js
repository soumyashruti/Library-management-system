import React from 'react';
import {Link} from 'react-router-dom'
import UserNavbar from '../../../navigationbar/Usernav';
export default function BookSearch() 
{
    return (
        <>
          <div>
            <UserNavbar/>
          </div>
            <h1>BookSearch</h1>
        </>
    )
}


















// {/* <div class="collapse navbar-collapse" id="navbarSupportedContent">
//                         <ul class="navbar-nav mr-auto">
//                         {/* <li class="nav-item active">
//                             <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
//                         </li>
//                         <li class="nav-item">
//                             <Link to="/About" class="nav-link" href="#">About</Link>
//                         </li>
//                         <li class="nav-item">
//                             <a class="nav-link" href="#">Admin</a>
//                             <i className="far fa-user-shield-alt"></i>
                            
//                         </li>
//                         <li class="nav-item">
//                             <a class="nav-link" href="#">User</a>
//                             <i className="far fa-user-alt"></i>
//                         </li> */}
//                         <li class="nav-item dropdown">
//                             <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
//                             Sections
//                             </a>
//                             <div class="dropdown-menu" aria-labelledby="navbarDropdown">
//                             <a class="dropdown-item" href="#">Section1</a>
//                             <a class="dropdown-item" href="#">Section2</a>
//                             <a class="dropdown-item" href="#">Section3</a>
//                             <div class="dropdown-divider"></div>
//                             <a class="dropdown-item" href="#">Other Section need to added</a>
//                             </div>
//                         </li>
//                         {/* <li class="nav-item">
//                             <a class="nav-link disabled" href="#" tabindex="-1" aria-disabled="true">Disabled</a>
//                         </li> */}
//                         </ul>
//                         <form class="form-inline my-2 my-lg-0">
//                         <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search"></input>
//                         <button class="btn btn-outline-primary my-2 my-sm-0" type="submit">Book Search</button>
//                         </form>
//                     </div>
//                 </nav>
//         </div>
//         {/* body part  */}
//         <div>
//              {/* <nav class="navbar navbar-light bg-info">
//                 <span class="navbar-brand mb-0 h1">My Library</span>
//                 <ul class="navbar-nav mr-auto">
//                     <li class="nav-item1 active">
//                         <Link class="nav-link" to="login">Login<span class="sr-only">(current)</span></Link>
//                     </li>
//                 </ul>
//             </nav> */} */}